1. Create a package named In_Class_Lab_3 in an existing project.
2. Paste the 2 classes from src file into the existing the package.
3. Open Java source files and paste the respective codes.
4.Run the programs to and examine the output.
5. As shown in the screenshot snippets in assignment report, validate the outputs with multiple correct and incorrect inputs.

----Contact Information for the group 
Sai Meghana Sangawar   - 500235387   - saimeghanasangawa@loyalistcollege.com
Jyothi Prasanna Kambam - 500233773   - jyothiprasannakam@loyalistcollege.com
Yamini Kunapareddy      - 500234808   - yaminikunapareddy@loyalistcollege.com
Sushma Kambam          - 500233832   - sushmakambam@loyalistcollege.com
Pranay Sai Chava       - 500236056   - paranaysaichava@loyalistcollege.com	
Shivaji Burgula        - 500224628   - shivajiburgula@loyalistcollege.com
