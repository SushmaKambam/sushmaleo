package In_Class_Lab_3;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Scanner;

/* StudentRecordSystem class provides functionalities to manage student records */
public class StudentRecordSystem {
    private static final String ANSI_RED = "\u001B[31m";
    private static final String ANSI_RESET = "\u001B[0m";

    private ArrayList<Student> students; // List to store student records.
    private Scanner scanner; // Scanner for user input.

    /* Constructor to initialize the student record system */
    public StudentRecordSystem() {
        students = new ArrayList<>();
        scanner = new Scanner(System.in);
    }

    /* Displays the menu and handles user choices */
    public void displayMenu() {
        int choice = 0;
        do {
            System.out.println("From the below Menu Select a choice from 1 to 6:");
            System.out.println("_____________________________________________________________");
            System.out.println("1. Add a new student record");
            System.out.println("2. Update an existing student record");
            System.out.println("3. Display all student records");
            System.out.println("4. Search for a student by ID");
            System.out.println("5. Calculate and display the average GPA of all students");
            System.out.println("6. Exit the program");
            System.out.println("--------------------------------------------------------------");
            System.out.print("Enter your choice: ");

            try {
                choice = Integer.parseInt(scanner.nextLine());

                switch (choice) {
                    case 1:
                        addStudent();
                        break;
                    case 2:
                        updateStudent();
                        break;
                    case 3:
                        displayAllStudents();
                        break;
                    case 4:
                        searchStudentByID();
                        break;
                    case 5:
                        calculateAverageGPA();
                        break;
                    case 6:
                        System.out.println("Exiting the program.");
                        break;
                    default:
                        System.out.println("Invalid choice. Please Select a valid choice.");
                }
            } catch (NumberFormatException e) {
                System.out.println(ANSI_RED + "Invalid input. Please enter a number between 1 and 6." + ANSI_RESET);
            }
        } while (choice != 6);
    }

    /* Adds a new student record */
    private void addStudent() {
        try {
            System.out.print("Enter student ID: ");
            String studentID = scanner.nextLine();
            
            if (!studentID.matches("\\d+")) {
                // If input is not numeric, throw an exception
                throw new IllegalArgumentException("Student ID should be a numeric value.");
            }

            if (findStudentByID(studentID) != null) {
                System.out.println(ANSI_RED + "Error: Student with ID " + studentID + " already exists." + ANSI_RESET);
                return;
            }

            System.out.print("Enter first name: ");
            String firstName = scanner.nextLine();
            if (!firstName.matches("[a-zA-Z]+")) {
                throw new IllegalArgumentException("First name should only contain alphabets.");
            }

            System.out.print("Enter last name: ");
            String lastName = scanner.nextLine();
            if (!lastName.matches("[a-zA-Z]+")) {
                throw new IllegalArgumentException("Last name should only contain alphabets.");
            }

            System.out.print("Enter date of birth (YYYY-MM-DD): ");
            String dateOfBirth = scanner.nextLine();
            LocalDate dob = LocalDate.parse(dateOfBirth); // This will throw an exception if the date format is invalid.

            // Validate that the month is between 1 and 12
            if (dob.getMonthValue() < 1 || dob.getMonthValue() > 12) {
                throw new IllegalArgumentException("Month in the date of birth should be between 1 and 12.");
            }

            System.out.print("Enter GPA: ");
            double gpa = Double.parseDouble(scanner.nextLine());

            // Validate GPA before creating the Student object
            if (gpa < 0.0 || gpa > 10.0) {
                throw new IllegalArgumentException("GPA must be between 0.0 and 10.0");
            }

            Student student = new Student(studentID, firstName, lastName, dateOfBirth, gpa);
            students.add(student); // Add the student to the list
            
            System.out.println("Student added successfully.");
        } catch (DateTimeParseException e) {
            System.out.println(ANSI_RED + "Invalid date format. Please enter the date in YYYY-MM-DD format." + ANSI_RESET);
        } catch (NumberFormatException e) {
            System.out.println(ANSI_RED + "Invalid input for GPA. Please enter a valid number." + ANSI_RESET);
        } catch (IllegalArgumentException e) {
            System.out.println(ANSI_RED + "Error: " + e.getMessage() + ANSI_RESET);
        } finally {
            // Prompt for confirmation to continue
            promptToContinue();
        }
    }

    /* Updates an existing student record */
    private void updateStudent() {
        try {
            System.out.print("Enter student ID to update: ");
            String studentID = scanner.nextLine();
            Student student = findStudentByID(studentID);

            if (student != null) {
                System.out.println("Student found: " + student);
                System.out.println("Enter new information:");

                System.out.print("Enter new first name (leave blank to keep current): ");
                String firstName = scanner.nextLine();
                if (!firstName.isEmpty()) {
                    if (!firstName.matches("[a-zA-Z]+")) {
                        throw new IllegalArgumentException("First name should only contain alphabets.");
                    }
                    student.setFirstName(firstName);
                }

                System.out.print("Enter new last name (leave blank to keep current): ");
             // Prompt the user to enter the last name
                String lastName = scanner.nextLine();
                // If the last name is not empty and contains only alphabets
                if (!lastName.isEmpty()) {
                    if (!lastName.matches("[a-zA-Z]+")) {
                        throw new IllegalArgumentException("Last name should only contain alphabets.");
                    }
                    // Set the last name of the student
                    student.setLastName(lastName);
                }

                // Prompt the user to enter the new date of birth
                System.out.print("Enter new date of birth (YYYY-MM-DD) (leave blank to keep current): ");
                String dateOfBirth = scanner.nextLine();
                // If the date of birth is not empty
                if (!dateOfBirth.isEmpty()) {
                    // Parse the date of birth string into a LocalDate object
                    LocalDate dob = LocalDate.parse(dateOfBirth);
                    // Validate that the month is between 1 and 12
                    if (dob.getMonthValue() < 1 || dob.getMonthValue() > 12) {
                        throw new IllegalArgumentException("Month in the date of birth should be between 1 and 12.");
                    }
                    // Set the date of birth of the student
                    student.setDateOfBirth(dateOfBirth);
                }

                // Prompt the user to enter the new GPA
                System.out.print("Enter new GPA (leave blank to keep current): ");
                String gpaStr = scanner.nextLine();
                // If the GPA is not empty
                if (!gpaStr.isEmpty()) {
                    // Parse the GPA string into a double
                    double gpa = Double.parseDouble(gpaStr);
                    // Validate that the GPA is between 0.0 and 10.0
                    if (gpa < 0.0 || gpa > 10.0) {
                        throw new IllegalArgumentException("GPA must be between 0.0 and 10.0");
                    }
                    // Set the GPA of the student
                    student.setGpa(gpa);
                }
                // Display a success message
                System.out.println("Student record updated successfully.");
            } else {
                // If the student is not found, display an error message
                System.out.println(ANSI_RED + "Student with ID " + studentID + " not found." + ANSI_RESET);
            }
        } catch (DateTimeParseException e) {
            // Catch block for handling invalid date format
            System.out.println(ANSI_RED + "Invalid date format. Please enter the date in YYYY-MM-DD format." + ANSI_RESET);
        } catch (NumberFormatException e) {
            // Catch block for handling invalid input for GPA
            System.out.println(ANSI_RED + "Invalid input for GPA. Please enter a valid number." + ANSI_RESET);
        } catch (IllegalArgumentException e) {
            // Catch block for handling other validation errors
            System.out.println(ANSI_RED + "Error: " + e.getMessage() + ANSI_RESET);
        } finally {
            // Prompt for confirmation to continue
            promptToContinue();
        }
    }

    /* Displays all student records */
    private void displayAllStudents() {
        if (students.isEmpty()) {
            System.out.println("No student records available.");
        } else {
            for (Student student : students) {
                System.out.println(student);
                System.out.println();
            }
        }
        // Prompt for confirmation to continue
        promptToContinue();
    }

    /* Searches for a student by ID and displays the record */
    private void searchStudentByID() {
        System.out.print("Enter student ID to search: ");
        String studentID = scanner.nextLine();
        Student student = findStudentByID(studentID);

        if (student != null) {
            System.out.println(student);
        } else {
            System.out.println(ANSI_RED + "Student with ID " + studentID + " not found." + ANSI_RESET);
        }
        // Prompt for confirmation to continue
        promptToContinue();
    }

    /* Calculates and displays the average GPA of all students */
    private void calculateAverageGPA() {
        if (students.isEmpty()) {
            System.out.println("No student records available.");
            // Prompt for confirmation to continue
            promptToContinue();
            return;
        }

        double totalGPA = 0.0;
        for (Student student : students) {
            totalGPA += student.getGpa();
        }

        double averageGPA = totalGPA / students.size();
        System.out.println("Average GPA: " + averageGPA);
        // Prompt for confirmation to continue
        promptToContinue();
    }

    /* Finds a student by ID */
    private Student findStudentByID(String studentID) {
        for (Student student : students) {
            if (student.getStudentID().equals(studentID)) {
                return student;
            }
        }
        return null;
    }

    /* Method to prompt for confirmation to continue */
    private void promptToContinue() {
        System.out.println("Press Enter to continue...");
        scanner.nextLine(); // Wait for user to press Enter
    }

    /* Main method to run the student record system */
    public static void main(String[] args) {
        StudentRecordSystem system = new StudentRecordSystem();
        system.displayMenu();
    }
}

