package In_Class_Lab_3;

import java.time.LocalDate;

/**
 * Student class represents a student with a unique ID, first name, last name,
 * date of birth, and GPA.
 */
public class Student {
    private String studentID;
    private String firstName;
    private String lastName;
    private LocalDate dateOfBirth;
    private double gpa;

    /**
     * Constructor to initialize a new Student object.
     *
     * @param studentID  Unique ID for the student.
     * @param firstName  First name of the student.
     * @param lastName   Last name of the student.
     * @param dateOfBirth Date of birth in the format "YYYY-MM-DD".
     * @param gpa        Grade Point Average.
     */
    public Student(String studentID, String firstName, String lastName, String dateOfBirth, double gpa) {
        this.studentID = studentID;
        this.firstName = firstName;
        this.lastName = lastName;
        this.dateOfBirth = LocalDate.parse(dateOfBirth);
        this.gpa = gpa;
    }

    // Getters and Setters
    public String getStudentID() {
        return studentID;
    }

    public void setStudentID(String studentID) {
        this.studentID = studentID;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public LocalDate getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = LocalDate.parse(dateOfBirth);
    }

    public double getGpa() {
        return gpa;
    }

    /**
     * Sets the GPA of the student. GPA must be between 0.0 and 4.0.
     *
     * @param gpa Grade Point Average.
     * @throws IllegalArgumentException if GPA is not within the valid range.
     */
    public void setGpa(double gpa) {
        if (gpa >= 0.0 && gpa <= 10.0) {
            this.gpa = gpa;
        } else {
            throw new IllegalArgumentException("GPA must be between 0.0 and 4.0");
        }
    }

    @Override
    public String toString() {
        return "Student ID: " + studentID + "\n" +
               "Name: " + firstName + " " + lastName + "\n" +
               "Date of Birth: " + dateOfBirth + "\n" +
               "GPA: " + gpa;
    }
}
