Front End Web Development - In Class Lab Assignment 1


Name: Sushma Kambam
Student Id: 500233832
Mail: sushmakambam@loyalistcollege.com


-------------------------------------------------------------------------------


Unzip file with filename as “500233832_Sushma_Assignment” in your computer

In this there are 3 coding files and one pdf with the screenshots of the code and the screenshots of the webpage

Coding files:
  index.html: Contains the structure of the form.
  script.js: Handles the form validation logic.
  styles.css: Provides styling for the form and the page.

Click on index.html a webpage containing a web form will be displayed.
You can test the form by entering name, address, date of birth, and email into the form.
The form will be validated, and if all fields are correctly filled out, a success message will be displayed.

If any fields are empty, it will show an error message saying "Please fill out this field" 
If the date of birth or email is in incorrect format,it shows a warning message as Please enter a valid date (MM/DD/YYYY)" ,"Please enter a valid email address". 
Validation Details:Name,Address,Date of Birth,Email